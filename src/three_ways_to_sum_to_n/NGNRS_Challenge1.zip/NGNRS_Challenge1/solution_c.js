var sum_to_n = function(n) {
  return n * (n + 1) / 2;
}

console.log( sum_to_n(5) );


