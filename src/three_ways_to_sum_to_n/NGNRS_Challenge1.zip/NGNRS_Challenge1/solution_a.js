var sum_to_n = function(n) {
    // your code here
    // let n = 5;
    let sum_to_n = 0;
    for (let i = 1; i <= n; i++) {
        sum_to_n += i;
    }
    return sum_to_n;
}
console.log( sum_to_n(5) );

